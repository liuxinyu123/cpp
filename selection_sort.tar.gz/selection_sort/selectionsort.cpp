#include "selectionsort.h"

void selectSort(int list[],int size)
{
	for(int i = size - 1; i > 0; --i)
	{
		int currentMax = list[0];
		int currentIndex = 0;

		for(int j = 0; j <= i;++j)
		{
			if(currentMax < list[j])
			{
				currentMax = list[j];
				currentIndex = j;
			}

		}
			if(currentIndex != i)
			{
				list[currentIndex] = list[i];
				list[i] = currentMax;
			}
	}
}

