#include <iostream>
#include "selectionsort.h"
#include "printarray.h"

int main()
{	
	int list[] = {4,35, 424,1 ,55,-1,24};
//	std::cout << "Please enter 6 interger numbers:\n";
//	int i = 6;
//	int list[6];
//	while(i--)
//		std::cin >> list[6-i];
	std::cout << "Before sort:\n";
	printArray(list,sizeof(list)/sizeof(list[0]));
	selectSort(list,sizeof(list)/sizeof(list[0]));
	std::cout << "After sort:\n";
	printArray(list,sizeof(list)/sizeof(list[0]));

	return 0;
}
