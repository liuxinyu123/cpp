#ifndef PRINT_ARRAY_H
#define PRINT_ARRAY_H

void printArray(int list[],int size);
#endif
