#include "printarray.h"
#include <iostream>

void printArray(int list[],int size)
{
	for(int i = 0; i < size; ++i)
	{
		std::cout << list[i] << " ";		
	}

	std::cout << std::endl;
}
