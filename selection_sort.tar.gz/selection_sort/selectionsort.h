#ifndef SELECT_SORT_H
#define SELECT_SORT_H 

void selectSort(int list[],int size);

#endif
