#include <fstream>
#include <iostream>
#include <string>
#include <cctype>

int main()
{
	std::ifstream f("hello.txt");
	std::string str;
	while(getline(f,str))
	{
		for(auto c : str)
		{
			c = toupper(c);
			std::cout << c;
		}
			
		std::cout << str << str.size()  << std::endl;
	
	}

	return 0;
}
